//Write the plugin setup

jQuery(document).ready(function(){
	jQuery('.rslides').responsiveSlides({

	})
})

